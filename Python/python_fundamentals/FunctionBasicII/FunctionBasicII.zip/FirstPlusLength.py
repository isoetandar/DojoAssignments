def firstPlusLength(arr):
    sum=arr[0]+len(arr)
    return sum

print(firstPlusLength([5,4,3,4,2]))