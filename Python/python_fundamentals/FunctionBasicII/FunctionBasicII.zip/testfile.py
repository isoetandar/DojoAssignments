b = 500
print(b)
def a():
    b = 300
    print(b)
    return b
print(b)
b=a()
print(b)