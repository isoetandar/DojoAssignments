def printAndReturn(a,b):
    print(a)
    return b

print(printAndReturn(2,25))