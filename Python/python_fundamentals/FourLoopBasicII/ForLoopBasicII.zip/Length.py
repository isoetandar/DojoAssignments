def Length(arr):
    return len(arr)


print(Length([1,2,3,4,5]))