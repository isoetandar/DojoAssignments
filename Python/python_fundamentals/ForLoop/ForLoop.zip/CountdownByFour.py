
for i in range(2018, 1, -4):
    print(i)