for i in range (1,101):
    if i%10 ==0:
        print("Coding")
    elif i%5==0:
        print("Dojo")
    else:
        print(i)
    