for i in range(0,151):
    print(i)