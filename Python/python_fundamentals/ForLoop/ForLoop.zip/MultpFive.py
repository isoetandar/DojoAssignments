i=5
while i < 10000001:
    print(i)
    i +=5