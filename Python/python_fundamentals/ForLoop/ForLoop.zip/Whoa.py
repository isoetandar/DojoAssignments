sum =0
for i in range (1,500001,2):
    sum +=i
    print(i)
print(sum)