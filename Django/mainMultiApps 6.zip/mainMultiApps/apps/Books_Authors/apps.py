from django.apps import AppConfig


class BlogAppConfig(AppConfig):
    name = 'Books_Authors_app'
