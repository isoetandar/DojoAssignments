from django.apps import AppConfig


class BlogAppConfig(AppConfig):
    name = 'timedisplay_app'
