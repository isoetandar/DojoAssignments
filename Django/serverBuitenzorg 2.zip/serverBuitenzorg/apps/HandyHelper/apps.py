from django.apps import AppConfig


class LoginandregistrationConfig(AppConfig):
    name = 'HandyHelper'
