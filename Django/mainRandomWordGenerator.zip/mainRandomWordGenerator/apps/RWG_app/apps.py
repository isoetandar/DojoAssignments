from django.apps import AppConfig


class BlogAppConfig(AppConfig):
    name = 'RWG_app'
