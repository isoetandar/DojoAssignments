from django.apps import AppConfig


class BlogAppConfig(AppConfig):
    name = 'surveys_app'
