from django.apps import AppConfig


class BlogAppConfig(AppConfig):
    name = 'amadon_app'
