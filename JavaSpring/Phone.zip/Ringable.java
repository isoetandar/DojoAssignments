public interface Ringable {
    // your code here
    String ring();
    String unlock();
}
