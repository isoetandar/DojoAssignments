package com.irwan.theCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheBushidoCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheBushidoCodeApplication.class, args);
	}
}
