package com.irwan.firstproject;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DojoController {
@RequestMapping("/{location}")
	public String showDojo(@PathVariable("location") String location) {
		if (location.equals("dojo")) {
			return "The Dojo is awesome";
			}
		else if (location.equals("burbank-dojo")) {
			return "Burbank Dojo is located in Southern California.";
			}
		else if (location.equals("san-jose")) {
			return  "SJ dojo is the headquarters";
			}
		else {
			return "no dojo at location";
		}
		
  	}
}

//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//@RestController
//public class HomeController {
//    @RequestMapping("/m/{track}/{module}/{lesson}")
//    public String showLesson(@PathVariable("track") String track, @PathVariable("module") String module, @PathVariable("lesson") String lesson){
//    	return "Track: " + track + ", Module: " + module + ", Lesson: " + lesson;
//    }
//}
