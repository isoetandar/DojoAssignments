public class GorillaTest {
    public static void main(String[] args){
        Gorilla gorilla = new Gorilla();
        gorilla.throwSomething();
        gorilla.throwSomething();
        gorilla.throwSomething();
        gorilla.eatBanana();
        gorilla.eatBanana();
        gorilla.climb();
        gorilla.displayEnergy();        
    }
}