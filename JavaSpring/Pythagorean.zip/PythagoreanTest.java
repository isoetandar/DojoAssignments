public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean Pythg = new Pythagorean();
        double legC = Pythg.calculateHypotenuse(3, 4);
        System.out.println(legC);
    }
}